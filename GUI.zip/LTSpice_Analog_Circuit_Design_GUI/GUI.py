import matplotlib
import matplotlib.pyplot
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import os
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import PhotoImage

class LTSAutoapp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        wind = tk.Toplevel()
        wind.wm_title("LTSpice/Python Analog Circuit Design GUI")

        l = tk.Label(wind, text="This software is still under development and should not be used \n"
                                "as part of the design of safety-critical or mission-critical circuits.")
        l.pack()

        b = ttk.Button(wind, text="Okay", command=wind.destroy)
        b.pack()
        wind.wm_attributes("-topmost", 1)
        wind.geometry("500x75")

        tk.Tk.iconbitmap(self, default="icon.ico")
        tk.Tk.wm_title(self, "LTSpice/Python Analog Circuit Design GUI")

        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=750)
        container.grid_columnconfigure(0, weight=750)

        self.frames = {}

        for F in (StartPage, PageOne, PageTwo, PageThree, PageFour, PageFive):

            frame = F(container, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label1 = tk.Label(self, text="Please Choose a Circuit to Simulate Below:", font="Veranda 14 bold")
        label1.pack(padx=10, pady=10)

        RC_Circuit = PhotoImage(file="RC_Circuit.PNG")
        label2 = tk.Label(self, image = RC_Circuit)
        label2.photo = RC_Circuit
        label2.place(x=10, y=40)

        button1 = ttk.Button(self, text = "   LP Filter\n(Sine Input)",
                             command=lambda: controller.show_frame(PageOne))
        button1.place(x=385, y=120)

        Inverter = PhotoImage(file="Inverter.PNG")
        label3 = tk.Label(self, image=Inverter)
        label3.photo = Inverter
        label3.place(x=10, y=240)

        button2 = ttk.Button(self, text="CMOS Inverter\n(Voltage Sweep)",
                             command=lambda: controller.show_frame(PageThree))
        button2.place(x = 380, y= 320)

        CMOS_OpAmp = PhotoImage(file="CMOS_OpAmp.PNG")
        label4 = tk.Label(self, image=CMOS_OpAmp)
        label4.photo = CMOS_OpAmp
        label4.place(x=250, y=440)

        button3 = ttk.Button(self, text="CMOS OpAmp",
                             command=lambda: controller.show_frame(PageFive))
        button3.place(x=625, y=520)

        button4 = ttk.Button(self, text="Exit",
                             command=quit)
        button4.place(x=445, y=650)

        HP_Circuit = PhotoImage(file="HP_Filter.PNG")
        label5 = tk.Label(self, image=HP_Circuit)
        label5.photo = HP_Circuit
        label5.place(x=475, y=40)

        button5 = ttk.Button(self, text="    HP Filter\n(Pulse Input)",
                             command=lambda: controller.show_frame(PageTwo))
        button5.place(x=850, y=120)

        CE_Amp = PhotoImage(file="CE_Amp.PNG")
        label6 = tk.Label(self, image=CE_Amp)
        label6.photo = CE_Amp
        label6.place(x=475, y=240)

        button6 = ttk.Button(self, text="CE Amplifier\n(Sine Input)",
                             command=lambda: controller.show_frame(PageFour))
        button6.place(x=850, y=320)

class PageOne(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Simple Low Pass Filter", font="Veranda 16 bold")
        label.pack(padx=10, pady=10)

        button1 = ttk.Button(self, text="<-- Back to Homescreen",
                             command=lambda: controller.show_frame(StartPage))
        button1.place(x=10, y=10)

        RC_Circuit = PhotoImage(file="RC_Circuit1.PNG")
        label1 = tk.Label(self, image=RC_Circuit)
        label1.photo = RC_Circuit
        label1.place(x=10, y=50)

        label2 = tk.Label(self, text="Set Component Values:", font = "Veranda 10 bold underline")
        label2.place(x=10, y=230)

        label3 = tk.Label(self, text="Default Values: {R}=100 \u03A9; {C}= 1 \u03BCF", font = "Veranda 8 italic", fg="red")
        label3.place(x=10, y=250)

        label4 = tk.Label(self, text="Resistor R1 {R}", font="Veranda 10")
        label4.place(x=10, y=270)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=110, y=270)

        var1 = tk.StringVar()
        radio1 = tk.Radiobutton(self, text='m\u03A9', variable=var1, value='A')
        radio1.place(x=140, y=270)
        radio2 = tk.Radiobutton(self, text='\u03A9', variable=var1, value='B')
        radio2.place(x=185, y=270)
        radio3 = tk.Radiobutton(self, text='k\u03A9', variable=var1, value='C')
        radio3.place(x=220, y=270)
        radio4 = tk.Radiobutton(self, text='M\u03A9', variable=var1, value='D')
        radio4.place(x=260, y=270)

        label6 = tk.Label(self, text="Capacitor C1 {C}", font="Veranda 10")
        label6.place(x=10, y=300)

        entry2 = tk.Entry(self, width=4)
        entry2.place(x=110, y=300)

        var2 = IntVar()
        radio5 = tk.Radiobutton(self, text='pF', variable=var2, value=1)
        radio5.place(x=140, y=300)
        radio6 = tk.Radiobutton(self, text='nF', variable=var2, value=2)
        radio6.place(x=185, y=300)
        radio7 = tk.Radiobutton(self, text='\u03BCF', variable=var2, value=3)
        radio7.place(x=220, y=300)
        radio8 = tk.Radiobutton(self, text='mF', variable=var2, value=4)
        radio8.place(x=260, y=300)

        label6 = tk.Label(self, text="Transient Simulation Length", font="Veranda 10")
        label6.place(x=10, y=330)
        entry3 = tk.Entry(self, width=4)
        entry3.place(x=190, y=330)
        label7 = tk.Label(self, text="ms", font="Veranda 10")
        label7.place(x=220, y=330)

        label12 = tk.Label(self, text="*Please fill in all fields and save values\nbefore rerunning simulation", font="Veranda 8 bold")
        label12.place(x=10, y=360)

        button2 = ttk.Button(self, text="Save Values", command=lambda: WriteParams())
        button2.place(x=60, y=395)

        button3 = ttk.Button(self, text="Rerun Simulation -->", command=lambda: PlotVoltage())
        button3.place(x=140, y=395)

        label8 = tk.Label(self, text="Plot View", font="Veranda 10 bold underline")
        label8.place(x=10, y=450)

        label9 = tk.Label(self, text="Please select a plot from below which you wish to view:", font = "Veranda 8 italic", fg="red")
        label9.place(x=10, y=470)

        var3 = tk.StringVar()
        radio9 = tk.Radiobutton(self, text='Input and Output Voltages', variable=var3, value='A', command=lambda: PlotVoltage())
        radio9.place(x=10, y=490)
        radio10 = tk.Radiobutton(self, text='Resistor Current', variable=var3, value='B', command=lambda: PlotCurrentR())
        radio10.place(x=10, y=515)
        radio11 = tk.Radiobutton(self, text='Capacitor Current', variable=var3, value='C', command=lambda: PlotCurrentC())
        radio11.place(x=10, y=540)
        radio12 = tk.Radiobutton(self, text='Frequency Reponse', variable=var3, value='D', command=lambda: ErrorBox())
        radio12.place(x=10, y=565)

        def RunSim():

            os.chdir("C:\LTC\LTspiceXVII")
            cmd = "XVIIx64.exe -Run -b C:\PycharmProjects\GUI\RC_Circuit.asc"
            os.system(cmd)
            os.chdir("C:\PycharmProjects\GUI")

        def PlotVoltage():
            RunSim()

            import ltspice

            l_1 = ltspice.Ltspice('RC_Circuit.raw')
            l_1.parse()

            time = l_1.getTime()
            time_1 = time * 1000
            V_source_1 = l_1.getData('V(source)')
            V_cap_1 = l_1.getData('V(cap)')

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(time_1, V_source_1, label="Source Voltage")
            a.plot(time_1, V_cap_1, label="Capacitor Voltage")
            a.set_xlabel('Time (ms)')
            a.set_ylabel('Voltage (V)')
            a.axis(xmin=min(time_1), xmax=max(time_1*1.1))
            a.axis(ymin=min(V_source_1*1.1), ymax=max(V_source_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentR():
            RunSim()

            import ltspice

            l_1 = ltspice.Ltspice('RC_Circuit.raw')
            l_1.parse()

            time = l_1.getTime()
            time_1 = time * 1000
            I_R_ = l_1.getData('I(R1)')
            I_R_1 = I_R_ * 1000
            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(time_1, I_R_1, label="Resistor Current")
            a.set_xlabel('Time (ms)')
            a.set_ylabel('Current (mA)')
            a.axis(xmin=min(time_1), xmax=max(time_1*1.1))
            a.axis(ymin=min(I_R_1*1.1), ymax=max(I_R_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentC():
            RunSim()

            import ltspice

            l_1 = ltspice.Ltspice('RC_Circuit.raw')
            l_1.parse()

            time = l_1.getTime()
            time_1 = time * 1000
            I_C_ = l_1.getData('I(C1)')
            I_C_1 = I_C_ * 1000
            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(time_1, I_C_1, label="Capacitor Current")
            a.set_xlabel('Time (ms)')
            a.set_ylabel('Current (mA)')
            a.axis(xmin=min(time_1), xmax=max(time_1*1.1))
            a.axis(ymin=min(I_C_1*1.1), ymax=max(I_C_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def ErrorBox():
            win = tk.Toplevel()
            win.wm_title("Error")

            l = tk.Label(win, text="Unfortunately, AC analysis cannot be done at this time.")
            l.pack()

            b = ttk.Button(win, text="Okay", command=win.destroy)
            b.pack()

        PlotVoltage()

        def WriteParams():

            file = "param_RC.txt"

            with open(file, "r+") as f:
                f.seek(0)
                if var1.get() == "A":
                    f.write(".param R %sE-03\n" % (entry1.get()))
                elif var1.get() == "B":
                    f.write(".param R %s\n" % (entry1.get()))
                elif var1.get() == "C":
                    f.write(".param R %sE03\n" % (entry1.get()))
                else:
                    f.write(".param R %sE06\n" % (entry1.get()))

                if var2.get() == 1:
                    f.write(".param C %sE-12\n" % (entry2.get()))
                elif var2.get() == 2:
                    f.write(".param C %sE-09\n" % (entry2.get()))
                elif var2.get() == 3:
                    f.write(".param C %sE-06\n" % (entry2.get()))
                else:
                    f.write(".param C %sE-03\n" % (entry2.get()))

                f.write(".param T %sm" % (entry3.get()))

                f.truncate()

class PageTwo(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Simple High Pass Filter", font="Veranda 16 bold")
        label.pack(padx=10, pady=10)

        button1 = ttk.Button(self, text="<-- Back to Homescreen",
                             command=lambda: controller.show_frame(StartPage))
        button1.place(x=10, y=10)

        RC_Circuit = PhotoImage(file="HP_Filter1.PNG")
        label1 = tk.Label(self, image=RC_Circuit)
        label1.photo = RC_Circuit
        label1.place(x=10, y=50)

        label2 = tk.Label(self, text="Set Component Values:", font = "Veranda 10 bold underline")
        label2.place(x=10, y=230)

        label3 = tk.Label(self, text="Default Values: {R}=100 \u03A9; {C}= 1 \u03BCF", font = "Veranda 8 italic", fg="red")
        label3.place(x=10, y=250)

        label4 = tk.Label(self, text="Resistor R1 {R}", font="Veranda 10")
        label4.place(x=10, y=270)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=110, y=270)

        var1 = tk.StringVar()
        radio1 = tk.Radiobutton(self, text='m\u03A9', variable=var1, value='A')
        radio1.place(x=140, y=270)
        radio2 = tk.Radiobutton(self, text='\u03A9', variable=var1, value='B')
        radio2.place(x=185, y=270)
        radio3 = tk.Radiobutton(self, text='k\u03A9', variable=var1, value='C')
        radio3.place(x=220, y=270)
        radio4 = tk.Radiobutton(self, text='M\u03A9', variable=var1, value='D')
        radio4.place(x=260, y=270)

        label6 = tk.Label(self, text="Capacitor C1 {C}", font="Veranda 10")
        label6.place(x=10, y=300)
        entry2 = tk.Entry(self, width=4)
        entry2.place(x=110, y=300)

        var2 = IntVar()
        radio5 = tk.Radiobutton(self, text='pF', variable=var2, value=1)
        radio5.place(x=140, y=300)
        radio6 = tk.Radiobutton(self, text='nF', variable=var2, value=2)
        radio6.place(x=185, y=300)
        radio7 = tk.Radiobutton(self, text='\u03BCF', variable=var2, value=3)
        radio7.place(x=220, y=300)
        radio8 = tk.Radiobutton(self, text='mF', variable=var2, value=4)
        radio8.place(x=260, y=300)

        label6 = tk.Label(self, text="Transient Simulation Length", font="Veranda 10")
        label6.place(x=10, y=330)
        entry3 = tk.Entry(self, width=4)
        entry3.place(x=190, y=330)
        label7 = tk.Label(self, text="ms", font="Veranda 10")
        label7.place(x=220, y=330)

        label6 = tk.Label(self, text="Pulse Input:", font="Veranda 10 underline")
        label6.place(x=120, y=360)

        label6 = tk.Label(self, text="Vin", font="Veranda 10")
        label6.place(x=30, y=385)
        entry4 = tk.Entry(self, width=4)
        entry4.place(x=90, y=385)
        label6 = tk.Label(self, text="V", font="Veranda 10")
        label6.place(x=120, y=385)

        label6 = tk.Label(self, text="Von", font="Veranda 10")
        label6.place(x=30, y=410)
        entry5 = tk.Entry(self, width=4)
        entry5.place(x=90, y=410)
        label6 = tk.Label(self, text="V", font="Veranda 10")
        label6.place(x=120, y=410)

        label6 = tk.Label(self, text="Ncycles", font="Veranda 10")
        label6.place(x=30, y=435)
        entry6 = tk.Entry(self, width=4)
        entry6.place(x=90, y=435)
        label6 = tk.Label(self, text="N", font="Veranda 10")
        label6.place(x=120, y=435)

        label6 = tk.Label(self, text="Tdelay", font="Veranda 10")
        label6.place(x=160, y=385)
        entry7 = tk.Entry(self, width=4)
        entry7.place(x=220, y=385)
        label6 = tk.Label(self, text="ms", font="Veranda 10")
        label6.place(x=250, y=385)

        label6 = tk.Label(self, text="Ton", font="Veranda 10")
        label6.place(x=160, y=410)
        entry8 = tk.Entry(self, width=4)
        entry8.place(x=220, y=410)
        label6 = tk.Label(self, text="ms", font="Veranda 10")
        label6.place(x=250, y=410)

        label6 = tk.Label(self, text="Period", font="Veranda 10")
        label6.place(x=160, y=435)
        entry9 = tk.Entry(self, width=4)
        entry9.place(x=220, y=435)
        label6 = tk.Label(self, text="ms", font="Veranda 10")
        label6.place(x=250, y=435)

        label12 = tk.Label(self, text="*Please fill in all fields and save values\nbefore rerunning simulation", font="Veranda 8 bold")
        label12.place(x=10, y=475)

        button2 = ttk.Button(self, text="Save Values", command=lambda: WriteParams())
        button2.place(x=60, y=515)

        button3 = ttk.Button(self, text="Rerun Simulation -->", command=lambda: PlotVoltage3())
        button3.place(x=140, y=515)

        label8 = tk.Label(self, text="Plot View", font="Veranda 10 bold underline")
        label8.place(x=10, y=540)

        label9 = tk.Label(self, text="Please select a plot from below which you wish to view:", font = "Veranda 8 italic", fg="red")
        label9.place(x=10, y=560)

        var3 = tk.StringVar()
        radio9 = tk.Radiobutton(self, text='Input and Output Voltages', variable=var3, value='A', command=lambda: PlotVoltage3())
        radio9.place(x=10, y=580)
        radio10 = tk.Radiobutton(self, text='Resistor Current', variable=var3, value='B', command=lambda: PlotCurrentR())
        radio10.place(x=10, y=605)
        radio11 = tk.Radiobutton(self, text='Capacitor Current', variable=var3, value='C', command=lambda: PlotCurrentC())
        radio11.place(x=10, y=630)


        def RunSim3():

            os.chdir("C:\LTC\LTspiceXVII")
            cmd = "XVIIx64.exe -Run -b C:\PycharmProjects\GUI\HP_Filter.asc"
            os.system(cmd)
            os.chdir("C:\PycharmProjects\GUI")

        def PlotVoltage3():
            RunSim3()

            import ltspice

            l_3 = ltspice.Ltspice('HP_Filter.raw')
            l_3.parse()

            time = l_3.getTime()
            time_3 = time * 1000
            V_in_3 = l_3.getData('V(vin)')
            V_out_3 = l_3.getData('V(vout)')

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(time_3, V_in_3, label="Input Voltage")
            a.plot(time_3, V_out_3, label="Output Voltage")
            a.set_xlabel('Time (ms)')
            a.set_ylabel('Voltage (V)')
            a.axis(xmin=min(time_3), xmax=max(time_3*1.1))
            a.axis(ymin=min(V_in_3*-1.1), ymax=max(V_in_3*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentR():
            RunSim3()

            import ltspice

            l_3 = ltspice.Ltspice('HP_Filter.raw')
            l_3.parse()

            time = l_3.getTime()
            time_3 = time * 1000
            I_R_ = l_3.getData('I(R1)')
            I_R_3 = I_R_ * 1000
            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(time_3, I_R_3, label="Resistor Current")
            a.set_xlabel('Time (ms)')
            a.set_ylabel('Current (mA)')
            a.axis(xmin=min(time_3), xmax=max(time_3*1.1))
            a.axis(ymin=min(I_R_3*1.1), ymax=max(I_R_3*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentC():
            RunSim3()

            import ltspice

            l_3 = ltspice.Ltspice('HP_Filter.raw')
            l_3.parse()

            time = l_3.getTime()
            time_3 = time * 1000
            I_C_ = l_3.getData('I(C1)')
            I_C_3 = I_C_ * 1000
            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(time_3, I_C_3, label="Capacitor Current")
            a.set_xlabel('Time (ms)')
            a.set_ylabel('Current (mA)')
            a.axis(xmin=min(time_3), xmax=max(time_3*1.1))
            a.axis(ymin=min(I_C_3*1.1), ymax=max(I_C_3*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        PlotVoltage3()

        def WriteParams():
            file = "param_HP.txt"
            with open(file, "r+") as f:
                f.seek(0)
                if var1.get() == "A":
                    f.write(".param R %sE-03\n" % (entry1.get()))
                elif var1.get() == "B":
                    f.write(".param R %s\n" % (entry1.get()))
                elif var1.get() == "C":
                    f.write(".param R %sE03\n" % (entry1.get()))
                else:
                    f.write(".param R %sE06\n" % (entry1.get()))

                if var2.get() == 1:
                    f.write(".param C %sE-12\n" % (entry2.get()))
                elif var2.get() == 2:
                    f.write(".param C %sE-09\n" % (entry2.get()))
                elif var2.get() == 3:
                    f.write(".param C %sE-06\n" % (entry2.get()))
                else:
                    f.write(".param C %sE-03\n" % (entry2.get()))
                f.write(".param T %sm\n" % (entry3.get()))
                f.write(".param V1 %s\n" % (entry4.get()))
                f.write(".param V2 %s\n" % (entry5.get()))
                f.write(".param N %s\n" % (entry6.get()))
                f.write(".param T1 %sm\n" % (entry7.get()))
                f.write(".param T2 %sm\n" % (entry8.get()))
                f.write(".param T3 %sm" % (entry9.get()))

                f.truncate()

class PageThree(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="CMOS Inverter", font="Veranda 16 bold")
        label.pack(padx=10, pady=10)

        button1 = ttk.Button(self, text="<-- Back to Homescreen",
                             command=lambda: controller.show_frame(StartPage))
        button1.place(x=10, y=10)

        Inverter = PhotoImage(file="Inverter1.PNG")
        label1 = tk.Label(self, image=Inverter)
        label1.photo = Inverter
        label1.place(x=10, y=50)

        label2 = tk.Label(self, text="Set Component Values:", font="Veranda 10 bold underline")
        label2.place(x=10, y=230)

        label3 = tk.Label(self, text="Default Values: W/L (M1) = 10\u03BC/1\u03BC; W/L (M2) = 10\u03BC/1\u03BC\n"
                                     "DC Sweep from 0 V to 5V in 0.1 V increments", font="Veranda 8 italic", fg="red")
        label3.place(x=10, y=250)

        label4 = tk.Label(self, text="Transistor M1", font="Veranda 10")
        label4.place(x=10, y=290)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=100, y=290)

        label5 = tk.Label(self, text="W", font="Veranda 10")
        label5.place(x=130, y=290)

        entry2 = tk.Entry(self, width=4)
        entry2.place(x=100, y=310)

        label6 = tk.Label(self, text="L", font="Veranda 10")
        label6.place(x=130, y=310)

        label7 = tk.Label(self, text="Transistor M2", font="Veranda 10")
        label7.place(x=10, y=330)

        entry3 = tk.Entry(self, width=4)
        entry3.place(x=100, y=330)

        label8 = tk.Label(self, text="W", font="Veranda 10")
        label8.place(x=130, y=330)

        entry4 = tk.Entry(self, width=4)
        entry4.place(x=100, y=350)

        label9 = tk.Label(self, text="L", font="Veranda 10")
        label9.place(x=130, y=350)

        label12 = tk.Label(self, text="DC Sweep:", font="Veranda 10")
        label12.place(x=170, y=290)

        entry5 = tk.Entry(self, width=4)
        entry5.place(x=180, y=310)

        label9 = tk.Label(self, text="Start Voltage", font="Veranda 10")
        label9.place(x=210, y=310)

        entry6 = tk.Entry(self, width=4)
        entry6.place(x=180, y=330)

        label9 = tk.Label(self, text="Stop Voltage", font="Veranda 10")
        label9.place(x=210, y=330)

        entry7 = tk.Entry(self, width=4)
        entry7.place(x=180, y=350)

        label9 = tk.Label(self, text="Increment", font="Veranda 10")
        label9.place(x=210, y=350)

        label3 = tk.Label(self, text="*Please fill in all fields and save values\nbefore rerunning simulation", font="Veranda 8 bold")
        label3.place(x=10, y=370)

        button2 = ttk.Button(self, text="Save Values", command=lambda: WriteParams())
        button2.place(x=60, y=405)

        button3 = ttk.Button(self, text="Rerun Simulation -->", command=lambda: PlotVoltage2())
        button3.place(x=140, y=405)

        label8 = tk.Label(self, text="Plot View", font="Veranda 10 bold underline")
        label8.place(x=10, y=435)

        label9 = tk.Label(self, text="Please select a plot from below which you wish to view:", font="Veranda 8 italic",
                          fg="red")
        label9.place(x=10, y=455)

        var3 = tk.StringVar()
        radio9 = tk.Radiobutton(self, text='Transfer Characteristic', variable=var3, value='A', command=lambda: PlotVoltage2())
        radio9.place(x=100, y=475)
        radio1 = tk.Radiobutton(self, text='M1 Drain Current', variable=var3, value='B', command=lambda: PlotCurrentM1d())
        radio1.place(x=10, y=500)
        radio2 = tk.Radiobutton(self, text='M1 Source Current', variable=var3, value='C', command=lambda: PlotCurrentM1s())
        radio2.place(x=10, y=525)
        radio3 = tk.Radiobutton(self, text='M1 Bulk Current', variable=var3, value='D', command=lambda: PlotCurrentM1b())
        radio3.place(x=10, y=550)
        radio4 = tk.Radiobutton(self, text='M1 Gate Current', variable=var3, value='E', command=lambda: PlotCurrentM1g())
        radio4.place(x=10, y=575)
        radio5 = tk.Radiobutton(self, text='M2 Drain Current', variable=var3, value='F', command=lambda: PlotCurrentM2d())
        radio5.place(x=170, y=500)
        radio6 = tk.Radiobutton(self, text='M2 Source Current', variable=var3, value='G', command=lambda: PlotCurrentM2s())
        radio6.place(x=170, y=525)
        radio7 = tk.Radiobutton(self, text='M2 Bulk Current', variable=var3, value='H', command=lambda: PlotCurrentM2b())
        radio7.place(x=170, y=550)
        radio4 = tk.Radiobutton(self, text='M2 Gate Current', variable=var3, value='E', command=lambda: PlotCurrentM2g())
        radio4.place(x=170, y=575)

        def RunSim2():

            os.chdir("C:\LTC\LTspiceXVII")
            cmd = "XVIIx64.exe -Run -b C:\PycharmProjects\GUI\Inverter.asc"
            os.system(cmd)
            os.chdir("C:\PycharmProjects\GUI")

        def PlotVoltage2():
            RunSim2()

            import ltspice

            l_2 = ltspice.Ltspice('Inverter.raw')
            l_2.parse()

            V_out_1 = l_2.getData('V(vout)')
            V_in_1 = l_2.getData('V(vin)')

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, V_out_1, label="Transfer Characteristic")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Vout (V)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(V_out_1), ymax=max(V_in_1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM1d():
            RunSim2()

            import ltspice

            l_3 = ltspice.Ltspice('Inverter.raw')
            l_3.parse()
            V_in_1 = l_3.getData('V(vin)')
            Id_M1_ = l_3.getData('Id(M1)')
            Id_M1_1 = Id_M1_ * 1000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Id_M1_1, label="M1 Drain Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Id M1 (\u03BCA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Id_M1_1), ymax=max(Id_M1_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM1s():
            import ltspice
            l_1 = ltspice.Ltspice('Inverter.raw')
            l_1.parse()
            V_in_1 = l_1.getData('V(Vin)')
            Is_M1_ = l_1.getData('Is(M1)')
            Is_M1_1 = Is_M1_ * 1000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Is_M1_1, label="M1 Source Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Is M1 (\u03BCA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Is_M1_1*1.1), ymax=max(Is_M1_1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM1b():
            import ltspice
            l_1 = ltspice.Ltspice('Inverter.raw')
            l_1.parse()
            V_in_1 = l_1.getData('V(Vin)')
            Ib_M1_ = l_1.getData('Ib(M1)')
            Ib_M1_1 = Ib_M1_ * 1000000000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Ib_M1_1, label="M1 Bulk Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Ib M1 (pA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Ib_M1_1*1.1), ymax=max(Ib_M1_1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM1g():
            import ltspice
            l_1 = ltspice.Ltspice('Inverter.raw')
            l_1.parse()
            V_in_1 = l_1.getData('V(Vin)')
            Ig_M1_ = l_1.getData('Ig(M1)')
            Ig_M1_1 = Ig_M1_ * 1000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Ig_M1_1, label="M1 Gate Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Ig M1 (\u03BCA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Ig_M1_1), ymax=max(Ig_M1_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM2d():
            import ltspice
            l_1 = ltspice.Ltspice('Inverter.raw')
            l_1.parse()
            V_in_1 = l_1.getData('V(vin)')
            Id_M2_ = l_1.getData('Id(M2)')
            Id_M2_1 = Id_M2_ * 1000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Id_M2_1, label="M2 Drain Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Id M2 (\u03BCA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Id_M2_1), ymax=max(Id_M2_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM2g():
            import ltspice
            l_1 = ltspice.Ltspice('Inverter.raw')
            l_1.parse()
            V_in_1 = l_1.getData('V(Vin)')
            Ig_M2_ = l_1.getData('Ig(M2)')
            Ig_M2_1 = Ig_M2_ * 1000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Ig_M2_1, label="M2 Gate Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Ig M2 (\u03BCA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Ig_M2_1), ymax=max(Ig_M2_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM2b():
            import ltspice
            l_1 = ltspice.Ltspice('Inverter.raw')
            l_1.parse()
            V_in_1 = l_1.getData('V(Vin)')
            Ib_M2_ = l_1.getData('Ib(M2)')
            Ib_M2_1 = Ib_M2_ * 1000000000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Ib_M2_1, label="M2 Bulk Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Ib M2 (pA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Ib_M2_1), ymax=max(Ib_M2_1*1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def PlotCurrentM2s():
            import ltspice
            l_1 = ltspice.Ltspice('Inverter.raw')
            l_1.parse()
            V_in_1 = l_1.getData('V(Vin)')
            Is_M2_ = l_1.getData('Is(M2)')
            Is_M2_1 = Is_M2_ * 1000000

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(V_in_1, Is_M2_1, label="M2 Source Current")
            a.set_xlabel('Vin (V)')
            a.set_ylabel('Is M2 (\u03BCA)')
            a.axis(xmin=min(V_in_1), xmax=max(V_in_1))
            a.axis(ymin=min(Is_M2_1*1.1), ymax=max(Is_M2_1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        PlotVoltage2()

        def WriteParams():

            file = "param_Inverter.txt"

            with open(file, "r+") as f:
                f.seek(0)
                f.write(".param W1 %s\n" % (entry1.get()))
                f.write(".param L1 %s\n" % (entry2.get()))
                f.write(".param W2 %s\n" % (entry3.get()))
                f.write(".param L2 %s\n" % (entry4.get()))
                f.write(".param V1 %s\n" % (entry5.get()))
                f.write(".param V2 %s\n" % (entry6.get()))
                f.write(".param V3 %s\n" % (entry7.get()))
                f.truncate()

class PageFour(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Common-Emitter Amplifier", font="Veranda 16 bold")
        label.pack(padx=10, pady=10)

        button1 = ttk.Button(self, text="<-- Back to Homescreen",
                             command=lambda: controller.show_frame(StartPage))
        button1.place(x=10, y=10)

        CE_Amp = PhotoImage(file="CE_Amp1.PNG")
        label1 = tk.Label(self, image=CE_Amp)
        label1.photo = CE_Amp
        label1.place(x=10, y=50)

        label2 = tk.Label(self, text="Set Component Values:", font = "Veranda 10 bold underline")
        label2.place(x=10, y=230)

        label3 = tk.Label(self, text="Default Values: {R1}=470 k\u03A9; {R2}=100 k\u03A9; {R3}=10 k\u03A9;\n {R4}=470 \u03A9; {RL}=10 k\u03A9; {C1}= 1 \u03BCF; {C2}= 0.1 \u03BCF", font = "Veranda 8 italic", fg="red")
        label3.place(x=10, y=250)

        label4 = tk.Label(self, text="Resistor {R1}", font="Veranda 10")
        label4.place(x=10, y=290)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=110, y=290)

        var1 = tk.StringVar()
        radio1 = tk.Radiobutton(self, text='m\u03A9', variable=var1, value='A')
        radio1.place(x=140, y=290)
        radio2 = tk.Radiobutton(self, text='\u03A9', variable=var1, value='B')
        radio2.place(x=185, y=290)
        radio3 = tk.Radiobutton(self, text='k\u03A9', variable=var1, value='C')
        radio3.place(x=220, y=290)
        radio4 = tk.Radiobutton(self, text='M\u03A9', variable=var1, value='D')
        radio4.place(x=260, y=290)

        label5 = tk.Label(self, text="Resistor {R2}", font="Veranda 10")
        label5.place(x=10, y=310)

        entry2 = tk.Entry(self, width=4)
        entry2.place(x=110, y=310)

        var2 = tk.StringVar()
        radio5 = tk.Radiobutton(self, text='m\u03A9', variable=var2, value='A')
        radio5.place(x=140, y=310)
        radio6 = tk.Radiobutton(self, text='\u03A9', variable=var2, value='B')
        radio6.place(x=185, y=310)
        radio7 = tk.Radiobutton(self, text='k\u03A9', variable=var2, value='C')
        radio7.place(x=220, y=310)
        radio8 = tk.Radiobutton(self, text='M\u03A9', variable=var2, value='D')
        radio8.place(x=260, y=310)

        label6 = tk.Label(self, text="Resistor {R3}", font="Veranda 10")
        label6.place(x=10, y=330)

        entry3 = tk.Entry(self, width=4)
        entry3.place(x=110, y=330)

        var3 = tk.StringVar()
        radio9 = tk.Radiobutton(self, text='m\u03A9', variable=var3, value='A')
        radio9.place(x=140, y=330)
        radio10 = tk.Radiobutton(self, text='\u03A9', variable=var3, value='B')
        radio10.place(x=185, y=330)
        radio11 = tk.Radiobutton(self, text='k\u03A9', variable=var3, value='C')
        radio11.place(x=220, y=330)
        radio12 = tk.Radiobutton(self, text='M\u03A9', variable=var3, value='D')
        radio12.place(x=260, y=330)

        label7 = tk.Label(self, text="Resistor {R4}", font="Veranda 10")
        label7.place(x=10, y=350)

        entry4 = tk.Entry(self, width=4)
        entry4.place(x=110, y=350)

        var4 = tk.StringVar()
        radio13 = tk.Radiobutton(self, text='m\u03A9', variable=var4, value='A')
        radio13.place(x=140, y=350)
        radio14 = tk.Radiobutton(self, text='\u03A9', variable=var4, value='B')
        radio14.place(x=185, y=350)
        radio15 = tk.Radiobutton(self, text='k\u03A9', variable=var4, value='C')
        radio15.place(x=220, y=350)
        radio16 = tk.Radiobutton(self, text='M\u03A9', variable=var4, value='D')
        radio16.place(x=260, y=350)

        label8 = tk.Label(self, text="Resistor {RL}", font="Veranda 10")
        label8.place(x=10, y=370)

        entry5 = tk.Entry(self, width=4)
        entry5.place(x=110, y=370)

        var5 = tk.StringVar()
        radio17 = tk.Radiobutton(self, text='m\u03A9', variable=var5, value='A')
        radio17.place(x=140, y=370)
        radio18 = tk.Radiobutton(self, text='\u03A9', variable=var5, value='B')
        radio18.place(x=185, y=370)
        radio19 = tk.Radiobutton(self, text='k\u03A9', variable=var5, value='C')
        radio19.place(x=220, y=370)
        radio20 = tk.Radiobutton(self, text='M\u03A9', variable=var5, value='D')
        radio20.place(x=260, y=370)

        label9 = tk.Label(self, text="Capacitor {C1}", font="Veranda 10")
        label9.place(x=10, y=390)

        entry6 = tk.Entry(self, width=4)
        entry6.place(x=110, y=390)

        var6 = IntVar()
        radio21 = tk.Radiobutton(self, text='pF', variable=var6, value=1)
        radio21.place(x=140, y=390)
        radio22 = tk.Radiobutton(self, text='nF', variable=var6, value=2)
        radio22.place(x=185, y=390)
        radio23 = tk.Radiobutton(self, text='\u03BCF', variable=var6, value=3)
        radio23.place(x=220, y=390)
        radio24 = tk.Radiobutton(self, text='mF', variable=var6, value=4)
        radio24.place(x=260, y=390)

        label10 = tk.Label(self, text="Capacitor {C2}", font="Veranda 10")
        label10.place(x=10, y=410)

        entry7 = tk.Entry(self, width=4)
        entry7.place(x=110, y=410)

        var7 = IntVar()
        radio25 = tk.Radiobutton(self, text='pF', variable=var7, value=1)
        radio25.place(x=140, y=410)
        radio26 = tk.Radiobutton(self, text='nF', variable=var7, value=2)
        radio26.place(x=185, y=410)
        radio27 = tk.Radiobutton(self, text='\u03BCF', variable=var7, value=3)
        radio27.place(x=220, y=410)
        radio28 = tk.Radiobutton(self, text='mF', variable=var7, value=4)
        radio28.place(x=260, y=410)

        label10 = tk.Label(self, text="Vcc", font="Veranda 10")
        label10.place(x=10, y=430)
        entry9 = tk.Entry(self, width=4)
        entry9.place(x=110, y=430)
        label10 = tk.Label(self, text="V", font="Veranda 10")
        label10.place(x=140, y=430)

        label10 = tk.Label(self, text="Transient Simulation Length", font="Veranda 10")
        label10.place(x=10, y=450)
        entry8 = tk.Entry(self, width=4)
        entry8.place(x=190, y=450)
        label11 = tk.Label(self, text="ms", font="Veranda 10")
        label11.place(x=220, y=450)

        label12 = tk.Label(self, text="*Please fill in all fields and save values\nbefore rerunning simulation",
                           font="Veranda 8 bold")
        label12.place(x=10, y=490)

        button2 = ttk.Button(self, text="Save Values", command=lambda: WriteParams())
        button2.place(x=60, y=525)

        button3 = ttk.Button(self, text="Rerun Simulation -->", command=lambda: PlotVoltage4())
        button3.place(x=140, y=525)

        label8 = tk.Label(self, text="Plot View", font="Veranda 10 bold underline")
        label8.place(x=10, y=550)

        label9 = tk.Label(self, text="Please select a plot from below which you wish to view:", font = "Veranda 8 italic", fg="red")
        label9.place(x=10, y=570)

        var8 = tk.StringVar()
        radio9 = tk.Radiobutton(self, text='Input and Output Voltages', variable=var8, value='A', command=lambda: PlotVoltage4())
        radio9.place(x=10, y=590)
        radio10 = tk.Radiobutton(self, text='Frequency Response', variable=var8, value='B', command=lambda: ErrorBox())
        radio10.place(x=10, y=615)

        def RunSim4():

            os.chdir("C:\LTC\LTspiceXVII")
            cmd = "XVIIx64.exe -Run -b C:\PycharmProjects\GUI\CE_Amp.asc"
            os.system(cmd)
            os.chdir("C:\PycharmProjects\GUI")

        def PlotVoltage4():
            RunSim4()

            import ltspice

            l_4 = ltspice.Ltspice('CE_Amp.raw')
            l_4.parse()

            time = l_4.getTime()
            time_4 = time * 1000
            V_in_1 = l_4.getData('V(n002)')
            V_out_1 = l_4.getData('V(vout)')

            f = Figure(figsize=(6, 6), dpi=100)
            a = f.add_subplot(111)
            a.grid(True)
            a.plot(time_4, V_in_1, label="Input Voltage")
            a.plot(time_4, V_out_1, label="Output Voltage")
            a.set_xlabel('Time (ms)')
            a.set_ylabel('Voltage (V)')
            a.axis(xmin=min(time_4), xmax=max(time_4 * 1.1))
            a.axis(ymin=min(V_out_1 * 1.1), ymax=max(V_out_1 * 1.1))
            a.legend(loc="upper right")

            canvas = FigureCanvasTkAgg(f, self)
            canvas.get_tk_widget().place(x=320, y=50)

            toolbar = NavigationToolbar2Tk(canvas, self)
            toolbar.update()
            toolbar.place(x=10, y=660)

        def ErrorBox():
            win = tk.Toplevel()
            win.wm_title("Error")

            l = tk.Label(win, text="Unfortunately, AC analysis cannot be done at this time.")
            l.pack()

            b = ttk.Button(win, text="Okay", command=win.destroy)
            b.pack()

        PlotVoltage4()


        def WriteParams():

            file = "param_CE.txt"

            with open(file, "r+") as f:
                f.seek(0)
                if var1.get() == "A":
                    f.write(".param R1 %sE-03\n" % (entry1.get()))
                elif var1.get() == "B":
                    f.write(".param R1 %s\n" % (entry1.get()))
                elif var1.get() == "C":
                    f.write(".param R1 %sE03\n" % (entry1.get()))
                else:
                    f.write(".param R1 %sE06\n" % (entry1.get()))

                if var2.get() == "A":
                    f.write(".param R2 %sE-03\n" % (entry2.get()))
                elif var2.get() == "B":
                    f.write(".param R2 %s\n" % (entry2.get()))
                elif var2.get() == "C":
                    f.write(".param R2 %sE03\n" % (entry2.get()))
                else:
                    f.write(".param R2 %sE06\n" % (entry2.get()))

                if var3.get() == "A":
                    f.write(".param R3 %sE-03\n" % (entry3.get()))
                elif var3.get() == "B":
                    f.write(".param R3 %s\n" % (entry3.get()))
                elif var3.get() == "C":
                    f.write(".param R3 %sE03\n" % (entry3.get()))
                else:
                    f.write(".param R3 %sE06\n" % (entry3.get()))

                if var4.get() == "A":
                    f.write(".param R4 %sE-03\n" % (entry4.get()))
                elif var4.get() == "B":
                    f.write(".param R4 %s\n" % (entry4.get()))
                elif var4.get() == "C":
                    f.write(".param R4 %sE03\n" % (entry4.get()))
                else:
                    f.write(".param R4 %sE06\n" % (entry4.get()))

                if var5.get() == "A":
                    f.write(".param RL %sE-03\n" % (entry5.get()))
                elif var5.get() == "B":
                    f.write(".param RL %s\n" % (entry5.get()))
                elif var5.get() == "C":
                    f.write(".param RL %sE03\n" % (entry5.get()))
                else:
                    f.write(".param RL %sE06\n" % (entry5.get()))

                if var6.get() == 1:
                    f.write(".param C1 %sE-12\n" % (entry6.get()))
                elif var6.get() == 2:
                    f.write(".param C1 %sE-09\n" % (entry6.get()))
                elif var6.get() == 3:
                    f.write(".param C1 %sE-06\n" % (entry6.get()))
                else:
                    f.write(".param C1 %sE-03\n" % (entry6.get()))

                if var7.get() == 1:
                    f.write(".param C2 %sE-12\n" % (entry7.get()))
                elif var7.get() == 2:
                    f.write(".param C2 %sE-09\n" % (entry7.get()))
                elif var7.get() == 3:
                    f.write(".param C2 %sE-06\n" % (entry7.get()))
                else:
                    f.write(".param C2 %sE-03\n" % (entry7.get()))
                f.write(".param T %sm\n" % (entry8.get()))
                f.write(".param V %s" % (entry9.get()))

                f.truncate()

class PageFive(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="CMOS Op-Amp", font="Veranda 16 bold")
        label.pack(padx=10, pady=10)

        button1 = ttk.Button(self, text="<-- Back to Homescreen",
                             command=lambda: controller.show_frame(StartPage))
        button1.place(x=10, y=10)

        Inverter = PhotoImage(file="CMOS_OpAmp1.PNG")
        label1 = tk.Label(self, image=Inverter)
        label1.photo = Inverter
        label1.place(x=10, y=50)

        label2 = tk.Label(self, text="Set Component Values:", font="Veranda 10 bold underline")
        label2.place(x=10, y=230)

        label3 = tk.Label(self, text="Default Values: W/L (M1) = 20\u03BC/1.6\u03BC; W/L (M2) = 20\u03BC/1.6\u03BC;\n"
                                     "W/L (M3) = 10\u03BC/1.6\u03BC; W/L (M4) = 10\u03BC/1.6\u03BC;\n W/L (M5) = 20\u03BC/1.6\u03BC"
                                     "W/L (M6) = 120\u03BC/1.6\u03BC;\n W/L (M7) = 20\u03BC/1.6\u03BC; W/L (M8) = 20\u03BC/1.6\u03BC\n",
                                        font="Veranda 8 italic", fg="red")
        label3.place(x=10, y=250)

        label4 = tk.Label(self, text="Transistor M1", font="Veranda 10")
        label4.place(x=10, y=330)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=100, y=330)

        label5 = tk.Label(self, text="W", font="Veranda 10")
        label5.place(x=130, y=330)

        entry2 = tk.Entry(self, width=4)
        entry2.place(x=100, y=350)

        label6 = tk.Label(self, text="L", font="Veranda 10")
        label6.place(x=130, y=350)

        label7 = tk.Label(self, text="Transistor M2", font="Veranda 10")
        label7.place(x=10, y=370)

        entry3 = tk.Entry(self, width=4)
        entry3.place(x=100, y=370)

        label8 = tk.Label(self, text="W", font="Veranda 10")
        label8.place(x=130, y=370)

        entry4 = tk.Entry(self, width=4)
        entry4.place(x=100, y=390)

        label9 = tk.Label(self, text="L", font="Veranda 10")
        label9.place(x=130, y=390)

        label4 = tk.Label(self, text="Transistor M3", font="Veranda 10")
        label4.place(x=10, y=410)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=100, y=410)

        label5 = tk.Label(self, text="W", font="Veranda 10")
        label5.place(x=130, y=410)

        entry2 = tk.Entry(self, width=4)
        entry2.place(x=100, y=430)

        label6 = tk.Label(self, text="L", font="Veranda 10")
        label6.place(x=130, y=430)

        label7 = tk.Label(self, text="Transistor M4", font="Veranda 10")
        label7.place(x=10, y=450)

        entry3 = tk.Entry(self, width=4)
        entry3.place(x=100, y=450)

        label8 = tk.Label(self, text="W", font="Veranda 10")
        label8.place(x=130, y=450)

        entry4 = tk.Entry(self, width=4)
        entry4.place(x=100, y=470)

        label9 = tk.Label(self, text="L", font="Veranda 10")
        label9.place(x=130, y=470)

        label4 = tk.Label(self, text="Transistor M5", font="Veranda 10")
        label4.place(x=170, y=330)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=260, y=330)

        label5 = tk.Label(self, text="W", font="Veranda 10")
        label5.place(x=290, y=330)

        entry2 = tk.Entry(self, width=4)
        entry2.place(x=260, y=350)

        label6 = tk.Label(self, text="L", font="Veranda 10")
        label6.place(x=290, y=350)

        label7 = tk.Label(self, text="Transistor M6", font="Veranda 10")
        label7.place(x=170, y=370)

        entry3 = tk.Entry(self, width=4)
        entry3.place(x=260, y=370)

        label8 = tk.Label(self, text="W", font="Veranda 10")
        label8.place(x=290, y=370)

        entry4 = tk.Entry(self, width=4)
        entry4.place(x=260, y=390)

        label9 = tk.Label(self, text="L", font="Veranda 10")
        label9.place(x=290, y=390)

        label4 = tk.Label(self, text="Transistor M7", font="Veranda 10")
        label4.place(x=170, y=410)

        entry1 = tk.Entry(self, width=4)
        entry1.place(x=260, y=410)

        label5 = tk.Label(self, text="W", font="Veranda 10")
        label5.place(x=290, y=410)

        entry2 = tk.Entry(self, width=4)
        entry2.place(x=260, y=430)

        label6 = tk.Label(self, text="L", font="Veranda 10")
        label6.place(x=290, y=430)

        label7 = tk.Label(self, text="Transistor M8", font="Veranda 10")
        label7.place(x=170, y=450)

        entry3 = tk.Entry(self, width=4)
        entry3.place(x=260, y=450)

        label8 = tk.Label(self, text="W", font="Veranda 10")
        label8.place(x=290, y=450)

        entry4 = tk.Entry(self, width=4)
        entry4.place(x=260, y=470)

        label9 = tk.Label(self, text="L", font="Veranda 10")
        label9.place(x=290, y=470)

        label3 = tk.Label(self, text="*Please fill in all fields and save values\nbefore rerunning simulation", font="Veranda 8 bold")
        label3.place(x=10, y=500)

        button2 = ttk.Button(self, text="Save Values")
        button2.place(x=60, y=535)

        button3 = ttk.Button(self, text="Rerun Simulation -->", command=lambda: ErrorBox())
        button3.place(x=140, y=535)

        label8 = tk.Label(self, text="Plot View", font="Veranda 10 bold underline")
        label8.place(x=10, y=570)

        label9 = tk.Label(self, text="Please select a plot from below which you wish to view:", font="Veranda 8 italic",
                          fg="red")
        label9.place(x=10, y=590)

        var3 = tk.StringVar()
        radio1 = tk.Radiobutton(self, text='Frequency Response', variable=var3, value='A', command=lambda: ErrorBox())
        radio1.place(x=10, y=610)

        def ErrorBox():
            win = tk.Toplevel()
            win.wm_title("Error")

            l = tk.Label(win, text="Unfortunately, AC analysis cannot be done at this time.")
            l.pack()

            b = ttk.Button(win, text="Okay", command=win.destroy)
            b.pack()

app = LTSAutoapp()
app.geometry("935x900")
app.mainloop()
